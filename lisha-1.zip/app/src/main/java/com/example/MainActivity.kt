package com.example

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.lisha.engine.PrivacyLockManager
import com.example.lisha.service.LishaAccessibilityService
import com.example.lisha.service.LishaAgentService
import com.example.lisha.ui.components.LishaBottomNav
import com.example.lisha.ui.components.LishaTopBar
import com.example.lisha.ui.components.PrivacyAuthModal
import com.example.lisha.ui.screens.DualEngineScreen
import com.example.lisha.ui.screens.HomeScreen
import com.example.lisha.ui.screens.MemoryVaultScreen
import com.example.lisha.ui.screens.MultiStepQueueScreen
import com.example.lisha.ui.screens.SystemControlScreen
import com.example.lisha.ui.screens.VoiceMatchScreen
import com.example.lisha.viewmodel.LishaScreen
import com.example.lisha.viewmodel.LishaViewModel
import com.example.ui.theme.LishaTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Start background agent service for wake-word and power optimization
        try {
            val serviceIntent = Intent(this, LishaAgentService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        } catch (e: Exception) {
            // Safe fallback if restricted
        }

        setContent {
            LishaTheme {
                LishaMainApp()
            }
        }
    }
}

@Composable
fun LishaMainApp(
    viewModel: LishaViewModel = viewModel()
) {
    val context = LocalContext.current
    val currentScreen by viewModel.currentScreen.collectAsState()
    val batteryLevel by viewModel.systemBatteryLevel.collectAsState()
    val ramUsage by viewModel.ramUsageMb.collectAsState()
    val isAccessibilityActive by LishaAccessibilityService.isAccessibilityActive.collectAsState()
    val isAuthModalOpen by PrivacyLockManager.isAuthModalOpen.collectAsState()
    val pendingAuthReason by PrivacyLockManager.pendingAuthReason.collectAsState()

    // Handle back button for sub-screens
    if (currentScreen != LishaScreen.HOME) {
        BackHandler {
            viewModel.navigateTo(LishaScreen.HOME)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            LishaTopBar(
                batteryLevel = batteryLevel,
                ramUsedMb = ramUsage.first,
                isAccessibilityOn = isAccessibilityActive,
                onSecurityClick = { viewModel.navigateTo(LishaScreen.VOICE_MATCH) }
            )
        },
        bottomBar = {
            LishaBottomNav(
                currentScreen = currentScreen,
                onNavigate = { viewModel.navigateTo(it) }
            )
        }
    ) { innerPadding ->
        val screenModifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)

        when (currentScreen) {
            LishaScreen.HOME -> HomeScreen(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) }, modifier = screenModifier)
            LishaScreen.TASK_QUEUE -> MultiStepQueueScreen(viewModel = viewModel, modifier = screenModifier)
            LishaScreen.MEMORY_VAULT -> MemoryVaultScreen(viewModel = viewModel, modifier = screenModifier)
            LishaScreen.DUAL_ENGINE -> DualEngineScreen(viewModel = viewModel, modifier = screenModifier)
            LishaScreen.VOICE_MATCH, LishaScreen.PRIVACY_LOCK -> VoiceMatchScreen(viewModel = viewModel, modifier = screenModifier)
            LishaScreen.SYSTEM_CONTROL -> SystemControlScreen(viewModel = viewModel, modifier = screenModifier)
        }
    }

    // Biometric & PIN Security Intercept Modal
    if (isAuthModalOpen) {
        PrivacyAuthModal(
            context = context,
            reason = pendingAuthReason,
            onDismiss = { PrivacyLockManager.cancelAuthentication() }
        )
    }
}
