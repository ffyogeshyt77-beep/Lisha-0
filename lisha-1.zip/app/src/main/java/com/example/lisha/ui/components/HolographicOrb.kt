package com.example.lisha.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LishaAlertRed
import com.example.ui.theme.LishaBorder
import com.example.ui.theme.LishaElectricViolet
import com.example.ui.theme.LishaMintSuccess
import com.example.ui.theme.LishaNeonCyan
import com.example.ui.theme.LishaPurpleGlow
import com.example.ui.theme.LishaSurfaceHigh

@Composable
fun HolographicOrb(
    isListening: Boolean,
    isSpeaking: Boolean,
    statusText: String,
    waveforms: List<Float>,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_pulse")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = if (isListening || isSpeaking) 1.15f else 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isListening || isSpeaking) 600 else 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isListening) 4000 else 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(200.dp)
                .testTag("holographic_orb")
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onClick
                ),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val baseRadius = (size.minDimension / 2f) * 0.72f * pulseScale

                // Outer atmospheric glow
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            if (isListening) LishaMintSuccess.copy(alpha = 0.25f)
                            else if (isSpeaking) LishaElectricViolet.copy(alpha = 0.35f)
                            else LishaNeonCyan.copy(alpha = 0.2f),
                            Color.Transparent
                        ),
                        center = center,
                        radius = baseRadius * 1.35f
                    ),
                    radius = baseRadius * 1.35f,
                    center = center
                )

                // Rotating energy ring 1
                drawCircle(
                    color = if (isListening) LishaMintSuccess.copy(alpha = 0.8f) else LishaNeonCyan.copy(alpha = 0.85f),
                    radius = baseRadius * 1.05f,
                    center = center,
                    style = Stroke(width = 2.5.dp.toPx())
                )

                // Rotating energy ring 2 (offset)
                drawCircle(
                    color = LishaPurpleGlow.copy(alpha = 0.7f),
                    radius = baseRadius * 1.14f,
                    center = center,
                    style = Stroke(width = 1.5.dp.toPx())
                )

                // Core orb gradient
                val coreBrush = Brush.radialGradient(
                    colors = if (isListening) {
                        listOf(Color.White, LishaMintSuccess, Color(0xFF004D40))
                    } else if (isSpeaking) {
                        listOf(Color.White, LishaPurpleGlow, LishaElectricViolet, Color(0xFF1A0A2A))
                    } else {
                        listOf(Color.White, LishaNeonCyan, Color(0xFF00384D), Color(0xFF070B16))
                    },
                    center = Offset(center.x - baseRadius * 0.2f, center.y - baseRadius * 0.2f),
                    radius = baseRadius
                )

                drawCircle(
                    brush = coreBrush,
                    radius = baseRadius * 0.85f,
                    center = center
                )

                // Specular holographic highlight
                drawCircle(
                    color = Color.White.copy(alpha = 0.45f),
                    radius = baseRadius * 0.25f,
                    center = Offset(center.x - baseRadius * 0.3f, center.y - baseRadius * 0.3f)
                )
            }

            // Live Audio Waveform Bars Inside/Across Orb
            Row(
                modifier = Modifier
                    .clip(CircleShape)
                    .padding(horizontal = 24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                waveforms.forEach { amp ->
                    val barHeight = 12.dp + (36 * amp).dp
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height(barHeight)
                            .clip(RoundedCornerShape(2.dp))
                            .padding(horizontal = 0.5.dp)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawRect(
                                brush = Brush.verticalGradient(
                                    colors = listOf(Color.White, LishaNeonCyan, LishaElectricViolet)
                                )
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(3.dp))
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // State indicator badge
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = LishaSurfaceHigh,
            border = androidx.compose.foundation.BorderStroke(1.dp, LishaBorder)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawCircle(
                            color = when {
                                isListening -> LishaMintSuccess
                                isSpeaking -> LishaElectricViolet
                                else -> LishaNeonCyan
                            }
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = when {
                        isListening -> "LISTENING (Voice Match Active)"
                        isSpeaking -> "SYNTHESIZING SPEECH"
                        else -> "AUTONOMOUS AGENT READY"
                    },
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = when {
                            isListening -> LishaMintSuccess
                            isSpeaking -> LishaPurpleGlow
                            else -> LishaNeonCyan
                        },
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = statusText,
            style = MaterialTheme.typography.bodyMedium.copy(
                color = Color.White.copy(alpha = 0.9f),
                fontWeight = FontWeight.Medium
            ),
            modifier = Modifier.padding(horizontal = 24.dp)
        )
    }
}
