package com.example.lisha.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.lisha.viewmodel.LishaScreen
import com.example.ui.theme.LishaBorder
import com.example.ui.theme.LishaElectricViolet
import com.example.ui.theme.LishaNeonCyan
import com.example.ui.theme.LishaObsidian
import com.example.ui.theme.LishaSurface
import com.example.ui.theme.LishaSurfaceHigh
import com.example.ui.theme.LishaTextPrimary
import com.example.ui.theme.LishaTextSecondary

@Composable
fun LishaBottomNav(
    currentScreen: LishaScreen,
    onNavigate: (LishaScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier
            .windowInsetsPadding(WindowInsets.navigationBars)
            .testTag("lisha_bottom_nav"),
        containerColor = LishaSurface,
        tonalElevation = 6.dp
    ) {
        val items = listOf(
            Triple(LishaScreen.HOME, "Home", Icons.Default.Home),
            Triple(LishaScreen.TASK_QUEUE, "Tasks", Icons.Default.AltRoute),
            Triple(LishaScreen.MEMORY_VAULT, "Memory", Icons.Default.Psychology),
            Triple(LishaScreen.DUAL_ENGINE, "Dual API", Icons.Default.Layers),
            Triple(LishaScreen.VOICE_MATCH, "Security", Icons.Default.Security),
            Triple(LishaScreen.SYSTEM_CONTROL, "Controls", Icons.Default.Tune)
        )

        items.forEach { (screen, label, icon) ->
            val isSelected = currentScreen == screen
            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(screen) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (isSelected) LishaNeonCyan else LishaTextSecondary
                    )
                },
                label = {
                    Text(
                        text = label,
                        color = if (isSelected) LishaNeonCyan else LishaTextSecondary
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = LishaNeonCyan.copy(alpha = 0.16f),
                    selectedIconColor = LishaNeonCyan,
                    unselectedIconColor = LishaTextSecondary
                ),
                modifier = Modifier.testTag("nav_${screen.name.lowercase()}")
            )
        }
    }
}
