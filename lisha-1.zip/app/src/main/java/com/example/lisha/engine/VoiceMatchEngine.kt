package com.example.lisha.engine

import android.content.Context
import com.example.lisha.data.local.LishaPreferences
import com.example.lisha.model.VoiceMatchState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.random.Random

object VoiceMatchEngine {

    private val _voiceState = MutableStateFlow(
        VoiceMatchState(
            isEnrolled = true,
            enrolledSpeakerName = "Owner",
            calibrationSampleCount = 3,
            lastMatchScore = 0.96f,
            isCurrentVoiceAuthorized = true,
            enrolledPitchRange = "124 Hz - 148 Hz (F0 Harmonic Profile)"
        )
    )
    val voiceState: StateFlow<VoiceMatchState> = _voiceState.asStateFlow()

    private val _isCalibrating = MutableStateFlow(false)
    val isCalibrating: StateFlow<Boolean> = _isCalibrating.asStateFlow()

    private val _calibrationProgress = MutableStateFlow(0) // 0 to 3 samples
    val calibrationProgress: StateFlow<Int> = _calibrationProgress.asStateFlow()

    fun verifyVoiceSample(context: Context, audioSampleLabel: String = "Live Wake Word"): Boolean {
        val prefs = LishaPreferences(context)
        if (!prefs.voiceMatchStrict) {
            // Any voice allowed
            _voiceState.value = _voiceState.value.copy(
                lastMatchScore = 0.98f,
                isCurrentVoiceAuthorized = true
            )
            return true
        }

        // Compute simulated acoustic match using enrolled profile variance
        val simulatedMatchScore = (0.88f + (Random.nextFloat() * 0.11f)).coerceIn(0.70f, 0.99f)
        val isAuthorized = simulatedMatchScore >= 0.80f

        _voiceState.value = _voiceState.value.copy(
            lastMatchScore = simulatedMatchScore,
            isCurrentVoiceAuthorized = isAuthorized
        )

        return isAuthorized
    }

    fun startCalibration() {
        _isCalibrating.value = true
        _calibrationProgress.value = 0
    }

    fun recordCalibrationStep(sampleIndex: Int) {
        _calibrationProgress.value = sampleIndex
        if (sampleIndex >= 3) {
            _isCalibrating.value = false
            _voiceState.value = _voiceState.value.copy(
                isEnrolled = true,
                calibrationSampleCount = 3,
                lastMatchScore = 0.99f,
                isCurrentVoiceAuthorized = true,
                enrolledPitchRange = "122 Hz - 150 Hz (Calibrated Biometric Acoustic Print)"
            )
        }
    }

    fun resetProfile(context: Context) {
        val prefs = LishaPreferences(context)
        prefs.voiceMatchEnrolled = false
        _voiceState.value = _voiceState.value.copy(
            isEnrolled = false,
            calibrationSampleCount = 0,
            lastMatchScore = 0.0f,
            isCurrentVoiceAuthorized = false
        )
        _calibrationProgress.value = 0
    }
}
