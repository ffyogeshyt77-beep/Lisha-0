package com.example.lisha.engine

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import android.util.Log
import com.example.lisha.service.LishaAccessibilityService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object AppAutomationManager {

    private var isTorchOn = false
    private val _torchState = MutableStateFlow(false)
    val torchState: StateFlow<Boolean> = _torchState.asStateFlow()

    private val _lastAutomationLog = MutableStateFlow("Ready for autonomous actions")
    val lastAutomationLog: StateFlow<String> = _lastAutomationLog.asStateFlow()

    fun launchAppByName(context: Context, appName: String): Boolean {
        val pm = context.packageManager
        val query = appName.trim().lowercase()

        // Known common mappings
        val knownPackages = mapOf(
            "whatsapp" to "com.whatsapp",
            "instagram" to "com.instagram.android",
            "telegram" to "org.telegram.messenger",
            "youtube" to "com.google.android.youtube",
            "camera" to "camera_intent",
            "settings" to "com.android.settings",
            "dialer" to "dialer_intent",
            "phone" to "dialer_intent",
            "maps" to "com.google.android.apps.maps",
            "chrome" to "com.android.chrome",
            "gmail" to "com.google.android.gm"
        )

        for ((key, target) in knownPackages) {
            if (query.contains(key)) {
                if (target == "camera_intent") {
                    return launchCamera(context)
                }
                if (target == "dialer_intent") {
                    return launchDialer(context)
                }
                val launchIntent = pm.getLaunchIntentForPackage(target)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    _lastAutomationLog.value = "Launched $key ($target)"
                    return true
                }
            }
        }

        // Search installed apps by label
        try {
            val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            for (appInfo in packages) {
                val label = pm.getApplicationLabel(appInfo).toString().lowercase()
                if (label.contains(query) || query.contains(label)) {
                    val intent = pm.getLaunchIntentForPackage(appInfo.packageName)
                    if (intent != null) {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                        _lastAutomationLog.value = "Launched $label (${appInfo.packageName})"
                        return true
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("AppAutomation", "Error finding app $appName", e)
        }

        _lastAutomationLog.value = "App '$appName' not installed or not found on device"
        return false
    }

    fun launchCamera(context: Context): Boolean {
        return try {
            val intent = Intent("android.media.action.IMAGE_CAPTURE").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            _lastAutomationLog.value = "Camera launched"
            true
        } catch (e: Exception) {
            val fallback = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(fallback)
                true
            } catch (ex: Exception) {
                _lastAutomationLog.value = "Camera launch failed"
                false
            }
        }
    }

    fun launchDialer(context: Context, phoneNumber: String = ""): Boolean {
        return try {
            val uri = if (phoneNumber.isNotBlank()) Uri.parse("tel:$phoneNumber") else Uri.parse("tel:")
            val intent = Intent(Intent.ACTION_DIAL, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            _lastAutomationLog.value = "Phone dialer opened for $phoneNumber"
            true
        } catch (e: Exception) {
            _lastAutomationLog.value = "Dialer launch failed"
            false
        }
    }

    fun toggleFlashlight(context: Context, forceState: Boolean? = null): Boolean {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            val cameraId = cameraManager?.cameraIdList?.firstOrNull() ?: return false
            val targetState = forceState ?: !isTorchOn
            cameraManager.setTorchMode(cameraId, targetState)
            isTorchOn = targetState
            _torchState.value = targetState
            _lastAutomationLog.value = if (targetState) "Flashlight turned ON" else "Flashlight turned OFF"
            true
        } catch (e: Exception) {
            Log.e("AppAutomation", "Flashlight toggle error", e)
            _lastAutomationLog.value = "Flashlight toggle unsupported or failed"
            false
        }
    }

    fun adjustVolume(context: Context, direction: Int): Boolean {
        return try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return false
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
            _lastAutomationLog.value = if (direction == AudioManager.ADJUST_RAISE) "Volume increased" else "Volume lowered"
            true
        } catch (e: Exception) {
            false
        }
    }

    fun openWifiSettings(context: Context): Boolean {
        return try {
            val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            _lastAutomationLog.value = "Wi-Fi settings opened"
            true
        } catch (e: Exception) {
            false
        }
    }

    fun openBluetoothSettings(context: Context): Boolean {
        return try {
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            _lastAutomationLog.value = "Bluetooth settings opened"
            true
        } catch (e: Exception) {
            false
        }
    }

    fun setAlarm(context: Context, hour: Int, minute: Int, message: String): Boolean {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            _lastAutomationLog.value = "Alarm set for $hour:$minute ($message)"
            true
        } catch (e: Exception) {
            _lastAutomationLog.value = "Could not set alarm via system intent"
            false
        }
    }

    fun lockScreenSafely(): Boolean {
        val success = LishaAccessibilityService.lockScreen()
        _lastAutomationLog.value = if (success) "Screen locked safely via Accessibility" else "Accessibility permission required to lock screen"
        return success
    }
}
