package com.example.lisha.data.local

import android.content.Context
import android.content.SharedPreferences

class LishaPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("lisha_agent_settings", Context.MODE_PRIVATE)

    var fastLiteApiKey: String
        get() = prefs.getString("fast_lite_api_key", "") ?: ""
        set(value) = prefs.edit().putString("fast_lite_api_key", value).apply()

    var fastLiteModel: String
        get() = prefs.getString("fast_lite_model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(value) = prefs.edit().putString("fast_lite_model", value).apply()

    var reasoningApiKey: String
        get() = prefs.getString("reasoning_api_key", "") ?: ""
        set(value) = prefs.edit().putString("reasoning_api_key", value).apply()

    var reasoningModel: String
        get() = prefs.getString("reasoning_model", "gemini-2.5-pro") ?: "gemini-2.5-pro"
        set(value) = prefs.edit().putString("reasoning_model", value).apply()

    var elevenLabsApiKey: String
        get() = prefs.getString("eleven_labs_api_key", "") ?: ""
        set(value) = prefs.edit().putString("eleven_labs_api_key", value).apply()

    var elevenLabsVoiceId: String
        get() = prefs.getString("eleven_labs_voice_id", "21m00Tcm4TlvDq8ikWAM") ?: "21m00Tcm4TlvDq8ikWAM"
        set(value) = prefs.edit().putString("eleven_labs_voice_id", value).apply()

    var ttsEngineType: String
        get() = prefs.getString("tts_engine_type", "SYSTEM") ?: "SYSTEM" // SYSTEM, ELEVENLABS, GEMINI
        set(value) = prefs.edit().putString("tts_engine_type", value).apply()

    var wakeWordEnabled: Boolean
        get() = prefs.getBoolean("wake_word_enabled", true)
        set(value) = prefs.edit().putBoolean("wake_word_enabled", value).apply()

    var wakeWordSensitivity: Float
        get() = prefs.getFloat("wake_word_sensitivity", 0.75f)
        set(value) = prefs.edit().putFloat("wake_word_sensitivity", value).apply()

    var voiceMatchEnrolled: Boolean
        get() = prefs.getBoolean("voice_match_enrolled", true)
        set(value) = prefs.edit().putBoolean("voice_match_enrolled", value).apply()

    var voiceMatchStrict: Boolean
        get() = prefs.getBoolean("voice_match_strict", true)
        set(value) = prefs.edit().putBoolean("voice_match_strict", value).apply()

    var ownerName: String
        get() = prefs.getString("owner_name", "Commander") ?: "Commander"
        set(value) = prefs.edit().putString("owner_name", value).apply()

    var callerAnnouncerEnabled: Boolean
        get() = prefs.getBoolean("caller_announcer_enabled", true)
        set(value) = prefs.edit().putBoolean("caller_announcer_enabled", value).apply()

    var messageAnnouncerEnabled: Boolean
        get() = prefs.getBoolean("message_announcer_enabled", true)
        set(value) = prefs.edit().putBoolean("message_announcer_enabled", value).apply()

    var announcerLanguage: String
        get() = prefs.getString("announcer_language", "HINGLISH") ?: "HINGLISH" // HINGLISH, ENGLISH, HINDI
        set(value) = prefs.edit().putString("announcer_language", value).apply()

    var privacyLockEnabled: Boolean
        get() = prefs.getBoolean("privacy_lock_enabled", true)
        set(value) = prefs.edit().putBoolean("privacy_lock_enabled", value).apply()

    var pinCode: String
        get() = prefs.getString("pin_code", "1234") ?: "1234"
        set(value) = prefs.edit().putString("pin_code", value).apply()

    var protectedPackages: Set<String>
        get() = prefs.getStringSet(
            "protected_packages",
            setOf(
                "com.google.android.apps.nbu.paisa.user", // Google Pay
                "net.one97.paytm", // Paytm
                "com.phonepe.app", // PhonePe
                "com.android.settings", // Settings
                "com.whatsapp" // WhatsApp
            )
        ) ?: emptySet()
        set(value) = prefs.edit().putStringSet("protected_packages", value).apply()

    var smartBatteryOptimization: Boolean
        get() = prefs.getBoolean("smart_battery_opt", true)
        set(value) = prefs.edit().putBoolean("smart_battery_opt", value).apply()

    var offlineRuleFallbackEnabled: Boolean
        get() = prefs.getBoolean("offline_fallback_enabled", true)
        set(value) = prefs.edit().putBoolean("offline_fallback_enabled", value).apply()
}
