package com.example.lisha.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.lisha.data.local.LishaPreferences
import com.example.lisha.engine.DualEngineManager
import com.example.lisha.model.WorkerState
import com.example.lisha.viewmodel.LishaViewModel
import com.example.ui.theme.LishaAlertRed
import com.example.ui.theme.LishaBorder
import com.example.ui.theme.LishaElectricViolet
import com.example.ui.theme.LishaMintSuccess
import com.example.ui.theme.LishaNeonCyan
import com.example.ui.theme.LishaObsidian
import com.example.ui.theme.LishaPurpleGlow
import com.example.ui.theme.LishaSurface
import com.example.ui.theme.LishaSurfaceHigh
import com.example.ui.theme.LishaTextPrimary
import com.example.ui.theme.LishaTextSecondary

@Composable
fun DualEngineScreen(
    viewModel: LishaViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val prefs = remember { LishaPreferences(context) }
    val dualStatus by DualEngineManager.engineStatus.collectAsState()
    val workerLog by DualEngineManager.liveWorkerLog.collectAsState()

    var fastLiteKey by remember { mutableStateOf(prefs.fastLiteApiKey) }
    var fastLiteModel by remember { mutableStateOf(prefs.fastLiteModel) }

    var reasoningKey by remember { mutableStateOf(prefs.reasoningApiKey) }
    var reasoningModel by remember { mutableStateOf(prefs.reasoningModel) }

    var offlineFallbackEnabled by remember { mutableStateOf(prefs.offlineRuleFallbackEnabled) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(LishaObsidian)
            .padding(16.dp)
            .testTag("dual_engine_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "DUAL API PARALLEL ENGINE",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = LishaTextPrimary,
                    letterSpacing = 1.sp
                )
            )
            Text(
                text = "Multi-threaded dual-key architecture. Fast Lite executes UI actions (<300ms); Heavy Reasoning generates plans & deep analysis.",
                style = MaterialTheme.typography.bodySmall.copy(color = LishaTextSecondary)
            )
        }

        // Live Parallel Thread HUD
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = LishaSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, LishaBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "REAL-TIME WORKER METRICS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = LishaNeonCyan,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Worker 1 Metric Box
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = LishaSurfaceHigh,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Bolt, contentDescription = null, tint = LishaNeonCyan, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("KEY 1: FAST LITE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = LishaNeonCyan)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "${dualStatus.fastLiteLatencyMs} ms",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                                Text(
                                    text = "${dualStatus.fastLiteCallCount} queries routed",
                                    fontSize = 10.sp,
                                    color = LishaTextSecondary
                                )
                            }
                        }

                        // Worker 2 Metric Box
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = LishaSurfaceHigh,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Psychology, contentDescription = null, tint = LishaPurpleGlow, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("KEY 2: REASONING", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = LishaPurpleGlow)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "${dualStatus.reasoningLatencyMs} ms",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                                Text(
                                    text = "${dualStatus.reasoningCallCount} queries routed",
                                    fontSize = 10.sp,
                                    color = LishaTextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Thread Log: $workerLog",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = LishaTextSecondary,
                            fontSize = 11.sp
                        )
                    )
                }
            }
        }

        // Key 1 Configuration: Fast Lite Worker
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = LishaSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, LishaBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "WORKER 1: FAST LITE KEY",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(LishaNeonCyan.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text("< 300ms SLA", color = LishaNeonCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text(
                        text = "Powers wake-word parsing, screen vision snapshots, and rapid intent navigation.",
                        style = MaterialTheme.typography.bodySmall.copy(color = LishaTextSecondary)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = fastLiteKey,
                        onValueChange = {
                            fastLiteKey = it
                            prefs.fastLiteApiKey = it
                        },
                        label = { Text("API Key 1 (Gemini Free Tier / Grok Lite / Custom)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("fast_lite_key_field"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LishaNeonCyan,
                            unfocusedBorderColor = LishaBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = fastLiteModel,
                        onValueChange = {
                            fastLiteModel = it
                            prefs.fastLiteModel = it
                        },
                        label = { Text("Model ID (e.g. gemini-2.5-flash)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LishaNeonCyan,
                            unfocusedBorderColor = LishaBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            DualEngineManager.testPingKey(isFastLite = true, fastLiteKey, fastLiteModel)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LishaSurfaceHigh),
                        modifier = Modifier.fillMaxWidth().testTag("test_ping_key1")
                    ) {
                        Icon(Icons.Default.NetworkCheck, contentDescription = null, tint = LishaNeonCyan, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Test Ping Key 1 Latency", color = LishaNeonCyan, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                }
            }
        }

        // Key 2 Configuration: Heavy Reasoning Worker
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = LishaSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, LishaBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "WORKER 2: REASONING KEY",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(LishaPurpleGlow.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text("DEEP THINKING", color = LishaPurpleGlow, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text(
                        text = "Powers deep Q&A, complex multi-step task planning, and creative content generation.",
                        style = MaterialTheme.typography.bodySmall.copy(color = LishaTextSecondary)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = reasoningKey,
                        onValueChange = {
                            reasoningKey = it
                            prefs.reasoningApiKey = it
                        },
                        label = { Text("API Key 2 (Gemini 2.5 Pro / Grok Reasoning / OpenAI)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("reasoning_key_field"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LishaPurpleGlow,
                            unfocusedBorderColor = LishaBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = reasoningModel,
                        onValueChange = {
                            reasoningModel = it
                            prefs.reasoningModel = it
                        },
                        label = { Text("Model ID (e.g. gemini-2.5-pro)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LishaPurpleGlow,
                            unfocusedBorderColor = LishaBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            DualEngineManager.testPingKey(isFastLite = false, reasoningKey, reasoningModel)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LishaSurfaceHigh),
                        modifier = Modifier.fillMaxWidth().testTag("test_ping_key2")
                    ) {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = LishaPurpleGlow, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Test Ping Key 2 Latency", color = LishaPurpleGlow, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                }
            }
        }

        // Offline Smart Intent Fallback
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = LishaSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, LishaBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.WifiOff, contentDescription = null, tint = LishaMintSuccess, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Offline Smart Intent Fallback",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Automatically switches to regex rule-engine if internet is lost or API quota is hit.",
                            style = MaterialTheme.typography.bodySmall.copy(color = LishaTextSecondary, fontSize = 11.sp)
                        )
                    }

                    Switch(
                        checked = offlineFallbackEnabled,
                        onCheckedChange = {
                            offlineFallbackEnabled = it
                            prefs.offlineRuleFallbackEnabled = it
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = LishaMintSuccess,
                            checkedTrackColor = LishaMintSuccess.copy(alpha = 0.3f)
                        ),
                        modifier = Modifier.testTag("offline_fallback_toggle")
                    )
                }
            }
        }
    }
}
