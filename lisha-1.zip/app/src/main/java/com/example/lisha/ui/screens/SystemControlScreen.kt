package com.example.lisha.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.lisha.data.local.LishaPreferences
import com.example.lisha.engine.AppAutomationManager
import com.example.lisha.engine.TtsManager
import com.example.lisha.service.LishaAccessibilityService
import com.example.lisha.service.LishaAgentService
import com.example.lisha.service.LishaNotificationListenerService
import com.example.lisha.viewmodel.LishaViewModel
import com.example.ui.theme.LishaAlertRed
import com.example.ui.theme.LishaBorder
import com.example.ui.theme.LishaElectricViolet
import com.example.ui.theme.LishaMintSuccess
import com.example.ui.theme.LishaNeonCyan
import com.example.ui.theme.LishaObsidian
import com.example.ui.theme.LishaPurpleGlow
import com.example.ui.theme.LishaSurface
import com.example.ui.theme.LishaSurfaceHigh
import com.example.ui.theme.LishaTextPrimary
import com.example.ui.theme.LishaTextSecondary

@Composable
fun SystemControlScreen(
    viewModel: LishaViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val prefs = remember { LishaPreferences(context) }
    val isAccessibilityActive by LishaAccessibilityService.isAccessibilityActive.collectAsState()
    val isNotificationListenerActive by LishaNotificationListenerService.isNotificationListenerActive.collectAsState()
    val isScreenSleeping by LishaAgentService.isScreenSleeping.collectAsState()
    val ramUsage by viewModel.ramUsageMb.collectAsState()
    val batteryLevel by viewModel.systemBatteryLevel.collectAsState()

    var smartBatteryOpt by remember { mutableStateOf(prefs.smartBatteryOptimization) }
    var callerAnnouncer by remember { mutableStateOf(prefs.callerAnnouncerEnabled) }
    var msgAnnouncer by remember { mutableStateOf(prefs.messageAnnouncerEnabled) }
    var language by remember { mutableStateOf(prefs.announcerLanguage) }

    var ttsType by remember { mutableStateOf(prefs.ttsEngineType) }
    var elevenLabsKey by remember { mutableStateOf(prefs.elevenLabsApiKey) }
    var elevenLabsVoiceId by remember { mutableStateOf(prefs.elevenLabsVoiceId) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(LishaObsidian)
            .padding(16.dp)
            .testTag("system_control_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "SYSTEM, TTS & BATTERY OPTIMIZATION",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = LishaTextPrimary,
                    letterSpacing = 1.sp
                )
            )
            Text(
                text = "Configure Accessibility automation, ElevenLabs realistic voice keys, and zero-drain sleep management.",
                style = MaterialTheme.typography.bodySmall.copy(color = LishaTextSecondary)
            )
        }

        // Accessibility & Notification Permissions Hub
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = LishaSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, LishaBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "AUTOMATION PRIVILEGES",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = LishaNeonCyan,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // Accessibility row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Accessibility, contentDescription = null, tint = if (isAccessibilityActive) LishaMintSuccess else LishaAlertRed, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Accessibility Service",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
                                )
                            }
                            Text(
                                text = if (isAccessibilityActive) "Active: UI tap simulation & screen reading enabled" else "Required for app clicks & lock screen",
                                style = MaterialTheme.typography.bodySmall.copy(color = LishaTextSecondary, fontSize = 11.sp)
                            )
                        }

                        Button(
                            onClick = {
                                try {
                                    val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    // Safe fallback
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = LishaSurfaceHigh),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("open_accessibility_settings")
                        ) {
                            Text(if (isAccessibilityActive) "Configured" else "Open Settings", fontSize = 11.sp, color = LishaNeonCyan)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Notification Listener row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Notifications, contentDescription = null, tint = if (isNotificationListenerActive) LishaMintSuccess else LishaAlertRed, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Notification Listener",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
                                )
                            }
                            Text(
                                text = if (isNotificationListenerActive) "Active: Smart caller & message announcer online" else "Required to read incoming caller IDs",
                                style = MaterialTheme.typography.bodySmall.copy(color = LishaTextSecondary, fontSize = 11.sp)
                            )
                        }

                        Button(
                            onClick = {
                                try {
                                    val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    // Safe fallback
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = LishaSurfaceHigh),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("open_notification_settings")
                        ) {
                            Text(if (isNotificationListenerActive) "Configured" else "Open Settings", fontSize = 11.sp, color = LishaNeonCyan)
                        }
                    }
                }
            }
        }

        // Voice Engine & ElevenLabs Configuration
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = LishaSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, LishaBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "VOICE SYNTHESIS & ELEVENLABS TTS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = LishaPurpleGlow,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("SYSTEM", "ELEVENLABS", "GEMINI").forEach { engine ->
                            val isSelected = ttsType == engine
                            Button(
                                onClick = {
                                    ttsType = engine
                                    prefs.ttsEngineType = engine
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) LishaPurpleGlow else LishaSurfaceHigh
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = engine,
                                    fontSize = 11.sp,
                                    color = if (isSelected) Color.White else LishaTextSecondary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = elevenLabsKey,
                        onValueChange = {
                            elevenLabsKey = it
                            prefs.elevenLabsApiKey = it
                        },
                        label = { Text("ElevenLabs API Key (Hyper-Realistic Speech)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LishaPurpleGlow,
                            unfocusedBorderColor = LishaBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = elevenLabsVoiceId,
                        onValueChange = {
                            elevenLabsVoiceId = it
                            prefs.elevenLabsVoiceId = it
                        },
                        label = { Text("Voice ID (Default: 21m00Tcm4TlvDq8ikWAM - Rachel)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LishaPurpleGlow,
                            unfocusedBorderColor = LishaBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            TtsManager.speak(context, "Hello, this is Lisha with enhanced speech synthesis.")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LishaSurfaceHigh),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = LishaPurpleGlow, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Test Speech Synthesis Voice", color = LishaPurpleGlow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Smart Battery & RAM Management
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = LishaSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, LishaBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "PERFORMANCE & BATTERY OPTIMIZER",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = LishaMintSuccess,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Zero Overnight Drain Standby",
                                style = MaterialTheme.typography.bodyMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Puts background mic and workers into intelligent sleep state when screen is OFF.",
                                style = MaterialTheme.typography.bodySmall.copy(color = LishaTextSecondary, fontSize = 11.sp)
                            )
                        }

                        Switch(
                            checked = smartBatteryOpt,
                            onCheckedChange = {
                                smartBatteryOpt = it
                                prefs.smartBatteryOptimization = it
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = LishaMintSuccess,
                                checkedTrackColor = LishaMintSuccess.copy(alpha = 0.3f)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = LishaSurfaceHigh,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("RAM FOOTPRINT", fontSize = 9.sp, color = LishaTextSecondary, fontWeight = FontWeight.Bold)
                                Text("${ramUsage.first} MB / ${ramUsage.second} MB", fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color.White)
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = LishaSurfaceHigh,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("BATTERY HEALTH", fontSize = 9.sp, color = LishaTextSecondary, fontWeight = FontWeight.Bold)
                                Text("$batteryLevel% • Optimal", fontSize = 14.sp, fontWeight = FontWeight.Black, color = LishaMintSuccess)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Safe Screen Power Lock
                    Button(
                        onClick = {
                            AppAutomationManager.lockScreenSafely()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LishaAlertRed.copy(alpha = 0.2f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = LishaAlertRed, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Turn Screen OFF (Power Lock)", color = LishaAlertRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
