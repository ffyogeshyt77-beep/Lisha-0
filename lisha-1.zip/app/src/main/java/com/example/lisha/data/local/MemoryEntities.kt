package com.example.lisha.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "personal_memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val keyPhrase: String,
    val content: String,
    val category: String = "FACT", // FACT, ROUTINE, NOTE, SECRET, ALARM_INFO
    val timestamp: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false,
    val queryCount: Int = 0
)

@Entity(tableName = "task_history")
data class TaskHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val originalPrompt: String,
    val stepsSummary: String,
    val engineName: String,
    val status: String, // SUCCESS, FAILED, PARTIAL
    val durationMs: Long,
    val timestamp: Long = System.currentTimeMillis()
)
