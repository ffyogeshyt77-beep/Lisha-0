package com.example.lisha.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryDao {

    @Query("SELECT * FROM personal_memories ORDER BY isPinned DESC, timestamp DESC")
    fun getAllMemories(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM personal_memories WHERE content LIKE '%' || :query || '%' OR keyPhrase LIKE '%' || :query || '%'")
    fun searchMemories(query: String): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM personal_memories WHERE keyPhrase LIKE '%' || :key || '%' LIMIT 1")
    suspend fun findByKey(key: String): MemoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: MemoryEntity): Long

    @Update
    suspend fun updateMemory(memory: MemoryEntity)

    @Query("DELETE FROM personal_memories WHERE id = :id")
    suspend fun deleteMemory(id: Long)

    @Query("SELECT * FROM task_history ORDER BY timestamp DESC LIMIT 50")
    fun getAllTaskHistory(): Flow<List<TaskHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTaskHistory(task: TaskHistoryEntity): Long

    @Query("DELETE FROM task_history")
    suspend fun clearTaskHistory()
}
