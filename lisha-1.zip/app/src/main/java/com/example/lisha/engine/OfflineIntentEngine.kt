package com.example.lisha.engine

import android.content.Context
import com.example.lisha.model.ActionType
import com.example.lisha.model.IntentType
import com.example.lisha.model.ParsedCommand
import com.example.lisha.model.StepStatus
import com.example.lisha.model.TaskStep
import java.util.UUID

object OfflineIntentEngine {

    fun parseOfflineCommand(input: String): ParsedCommand {
        val trimmed = input.trim()
        val lower = trimmed.lowercase()

        // Check for compound command connectors: "aur", "and", "then", "fir", ","
        val segments = splitCompoundPrompt(trimmed)
        if (segments.size > 1) {
            val steps = segments.mapIndexed { index, seg ->
                createStepFromSegment(index + 1, seg)
            }
            return ParsedCommand(
                rawText = trimmed,
                intentType = IntentType.MULTI_STEP,
                confidence = 0.96f,
                steps = steps,
                directSpokenResponse = "Executing ${steps.size} offline actions sequentially."
            )
        }

        // Memory Remember ("Ye yaad rakho ki ...", "Remember that ...", "Save note ...")
        if (lower.startsWith("ye yaad rakho") || lower.startsWith("remember") || lower.startsWith("yaad rakhna") || lower.contains("yaad rakho")) {
            val content = trimmed
                .replace(Regex("(?i)^(ye yaad rakho ki|ye yaad rakho|remember that|remember|yaad rakhna ki|yaad rakho)"), "")
                .trim()
            val key = extractMemoryKey(content)
            return ParsedCommand(
                rawText = trimmed,
                intentType = IntentType.SAVE_MEMORY,
                confidence = 0.98f,
                memoryKey = key,
                memoryValue = content,
                directSpokenResponse = "Maine yaad rakh liya: $content"
            )
        }

        // Memory Recall ("Mera parking kaha hai", "Where did I park", "What is my wifi password")
        if (lower.contains("kaha hai") || lower.contains("where is") || lower.contains("kya hai") || lower.contains("what is") || lower.contains("batao")) {
            val queryKey = extractQueryKey(lower)
            return ParsedCommand(
                rawText = trimmed,
                intentType = IntentType.RECALL_MEMORY,
                confidence = 0.94f,
                memoryKey = queryKey,
                directSpokenResponse = null // Will be looked up in Room DB
            )
        }

        // Screen Lock
        if (lower.contains("screen band") || lower.contains("lock screen") || lower.contains("phone lock") || lower.contains("screen off")) {
            val step = TaskStep(
                id = UUID.randomUUID().toString(),
                title = "Lock Screen",
                description = "Safely locking display via Accessibility",
                actionType = ActionType.SCREEN_LOCK,
                target = "system_lock"
            )
            return ParsedCommand(
                rawText = trimmed,
                intentType = IntentType.APP_CONTROL,
                confidence = 0.99f,
                steps = listOf(step),
                directSpokenResponse = "Screen lock kar di gayi hai."
            )
        }

        // Flashlight / Torch
        if (lower.contains("torch") || lower.contains("flashlight")) {
            val state = !lower.contains("off") && !lower.contains("band")
            val step = TaskStep(
                id = UUID.randomUUID().toString(),
                title = if (state) "Turn ON Flashlight" else "Turn OFF Flashlight",
                description = "Hardware Camera Flashlight toggle",
                actionType = ActionType.TOGGLE_SETTING,
                target = if (state) "torch_on" else "torch_off"
            )
            return ParsedCommand(
                rawText = trimmed,
                intentType = IntentType.SYSTEM_TOGGLE,
                confidence = 0.99f,
                steps = listOf(step),
                directSpokenResponse = if (state) "Flashlight chalu kar di hai." else "Flashlight band kar di."
            )
        }

        // Wi-Fi or Bluetooth
        if (lower.contains("wifi") || lower.contains("wi-fi")) {
            val step = TaskStep(
                id = UUID.randomUUID().toString(),
                title = "Wi-Fi Settings",
                description = "Open System Wi-Fi network configuration",
                actionType = ActionType.TOGGLE_SETTING,
                target = "wifi_settings"
            )
            return ParsedCommand(
                rawText = trimmed,
                intentType = IntentType.SYSTEM_TOGGLE,
                confidence = 0.95f,
                steps = listOf(step),
                directSpokenResponse = "Wi-Fi settings open kar di hai."
            )
        }
        if (lower.contains("bluetooth")) {
            val step = TaskStep(
                id = UUID.randomUUID().toString(),
                title = "Bluetooth Settings",
                description = "Open Bluetooth device pairing",
                actionType = ActionType.TOGGLE_SETTING,
                target = "bluetooth_settings"
            )
            return ParsedCommand(
                rawText = trimmed,
                intentType = IntentType.SYSTEM_TOGGLE,
                confidence = 0.95f,
                steps = listOf(step),
                directSpokenResponse = "Bluetooth settings open kar di hai."
            )
        }

        // Volume
        if (lower.contains("volume")) {
            val isUp = lower.contains("up") || lower.contains("badhao") || lower.contains("badao") || lower.contains("increase")
            val step = TaskStep(
                id = UUID.randomUUID().toString(),
                title = if (isUp) "Increase Volume" else "Decrease Volume",
                description = "Adjust audio media volume stream",
                actionType = ActionType.TOGGLE_SETTING,
                target = if (isUp) "volume_up" else "volume_down"
            )
            return ParsedCommand(
                rawText = trimmed,
                intentType = IntentType.SYSTEM_TOGGLE,
                confidence = 0.98f,
                steps = listOf(step),
                directSpokenResponse = if (isUp) "Volume badha diya hai." else "Volume kam kar diya hai."
            )
        }

        // Call / Dialer
        if (lower.startsWith("call") || lower.contains("ko call") || lower.contains("call karo")) {
            val target = trimmed.replace(Regex("(?i)(call|ko call karo|call karo)"), "").trim()
            val step = TaskStep(
                id = UUID.randomUUID().toString(),
                title = "Initiate Call",
                description = "Opening dialer for $target",
                actionType = ActionType.MAKE_CALL,
                target = target
            )
            return ParsedCommand(
                rawText = trimmed,
                intentType = IntentType.CALL_OR_MESSAGE,
                confidence = 0.95f,
                steps = listOf(step),
                directSpokenResponse = "$target ko call milaya ja raha hai."
            )
        }

        // Alarm
        if (lower.contains("alarm")) {
            val step = TaskStep(
                id = UUID.randomUUID().toString(),
                title = "Set System Alarm",
                description = "Setting alarm via Clock Provider",
                actionType = ActionType.TOGGLE_SETTING,
                target = "alarm_clock"
            )
            return ParsedCommand(
                rawText = trimmed,
                intentType = IntentType.SYSTEM_TOGGLE,
                confidence = 0.95f,
                steps = listOf(step),
                directSpokenResponse = "Alarm set kar diya hai."
            )
        }

        // App Launch: "kholo", "open", "launch", "chalu karo"
        val detectedAppName = extractAppName(lower)
        if (detectedAppName != null) {
            val step = TaskStep(
                id = UUID.randomUUID().toString(),
                title = "Launch App",
                description = "Launching $detectedAppName",
                actionType = ActionType.OPEN_APP,
                target = detectedAppName
            )
            val requiresAuth = detectedAppName in listOf("phonepe", "paytm", "gpay", "google pay", "bank")
            return ParsedCommand(
                rawText = trimmed,
                intentType = IntentType.APP_CONTROL,
                confidence = 0.95f,
                steps = listOf(step),
                targetPackage = detectedAppName,
                requiresPrivacyAuth = requiresAuth,
                directSpokenResponse = "$detectedAppName open kiya ja raha hai."
            )
        }

        // Default General Intent
        return ParsedCommand(
            rawText = trimmed,
            intentType = IntentType.GENERAL_QA,
            confidence = 0.85f,
            directSpokenResponse = "Aapka aadesh sun liya: $trimmed. Dual-Engine aur offline automation tayyar hai."
        )
    }

    private fun splitCompoundPrompt(text: String): List<String> {
        val delimiters = listOf(" aur fir ", " aur ", " and then ", " and ", " then ", " fir ", ", ")
        var segments = listOf(text)
        for (del in delimiters) {
            segments = segments.flatMap { it.split(del) }
        }
        return segments.map { it.trim() }.filter { it.isNotEmpty() }
    }

    private fun createStepFromSegment(index: Int, segment: String): TaskStep {
        val lower = segment.lowercase()
        val (actionType, target, title) = when {
            lower.contains("wifi") || lower.contains("wi-fi") ->
                Triple(ActionType.TOGGLE_SETTING, "wifi_settings", "Step $index: Enable Wi-Fi")
            lower.contains("torch") || lower.contains("flashlight") ->
                Triple(ActionType.TOGGLE_SETTING, "torch_on", "Step $index: Toggle Flashlight")
            lower.contains("camera") ->
                Triple(ActionType.OPEN_APP, "camera", "Step $index: Launch Camera")
            lower.contains("instagram") ->
                Triple(ActionType.OPEN_APP, "instagram", "Step $index: Open Instagram")
            lower.contains("whatsapp") ->
                Triple(ActionType.OPEN_APP, "whatsapp", "Step $index: Open WhatsApp")
            lower.contains("telegram") ->
                Triple(ActionType.OPEN_APP, "telegram", "Step $index: Open Telegram")
            lower.contains("youtube") ->
                Triple(ActionType.OPEN_APP, "youtube", "Step $index: Open YouTube")
            lower.contains("message") ->
                Triple(ActionType.SEND_MESSAGE, "recipient_chat", "Step $index: Send Message")
            lower.contains("call") ->
                Triple(ActionType.MAKE_CALL, segment.replace("call", "").trim(), "Step $index: Initiate Call")
            lower.contains("lock") ->
                Triple(ActionType.SCREEN_LOCK, "system_lock", "Step $index: Lock Screen")
            else ->
                Triple(ActionType.CUSTOM_INTENT, segment, "Step $index: Execute '$segment'")
        }

        return TaskStep(
            id = UUID.randomUUID().toString(),
            title = title,
            description = segment,
            actionType = actionType,
            target = target,
            status = StepStatus.PENDING
        )
    }

    private fun extractAppName(lower: String): String? {
        val apps = listOf(
            "whatsapp", "instagram", "telegram", "youtube", "camera",
            "chrome", "settings", "phonepe", "paytm", "gpay", "google pay",
            "maps", "gmail", "clock", "gallery", "calculator"
        )
        for (app in apps) {
            if (lower.contains(app)) return app
        }
        if (lower.contains("kholo") || lower.contains("open") || lower.contains("launch")) {
            return lower.replace(Regex("(kholo|open|launch|chalu karo|app)"), "").trim()
        }
        return null
    }

    private fun extractMemoryKey(content: String): String {
        val lower = content.lowercase()
        return when {
            lower.contains("parking") || lower.contains("car") -> "car_parking"
            lower.contains("birthday") || lower.contains("janamdin") -> "birthday"
            lower.contains("wifi") || lower.contains("password") -> "wifi_password"
            lower.contains("medicine") || lower.contains("dawai") -> "medicine_schedule"
            lower.contains("office") -> "office_location"
            else -> content.take(24).trim()
        }
    }

    private fun extractQueryKey(lower: String): String {
        return when {
            lower.contains("parking") || lower.contains("car") -> "car_parking"
            lower.contains("birthday") -> "birthday"
            lower.contains("wifi") -> "wifi_password"
            lower.contains("medicine") -> "medicine_schedule"
            else -> lower.replace(Regex("(mera|kaha hai|where is|what is|kya hai|batao|the|my)"), "").trim()
        }
    }
}
