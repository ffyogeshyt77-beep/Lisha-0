package com.example.lisha.data.local

import kotlinx.coroutines.flow.Flow

class MemoryRepository(private val dao: MemoryDao) {

    val allMemories: Flow<List<MemoryEntity>> = dao.getAllMemories()
    val allTasks: Flow<List<TaskHistoryEntity>> = dao.getAllTaskHistory()

    fun searchMemories(query: String): Flow<List<MemoryEntity>> = dao.searchMemories(query)

    suspend fun findMemory(key: String): MemoryEntity? = dao.findByKey(key)

    suspend fun saveMemory(key: String, content: String, category: String = "FACT"): Long {
        val entity = MemoryEntity(
            keyPhrase = key.trim(),
            content = content.trim(),
            category = category
        )
        return dao.insertMemory(entity)
    }

    suspend fun updateMemory(memory: MemoryEntity) = dao.updateMemory(memory)

    suspend fun deleteMemory(id: Long) = dao.deleteMemory(id)

    suspend fun recordTaskExecution(
        prompt: String,
        summary: String,
        engine: String,
        status: String,
        durationMs: Long
    ): Long {
        val task = TaskHistoryEntity(
            originalPrompt = prompt,
            stepsSummary = summary,
            engineName = engine,
            status = status,
            durationMs = durationMs
        )
        return dao.insertTaskHistory(task)
    }

    suspend fun clearHistory() = dao.clearTaskHistory()
}
