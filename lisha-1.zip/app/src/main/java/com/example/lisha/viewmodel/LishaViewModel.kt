package com.example.lisha.viewmodel

import android.app.Application
import android.content.Context
import android.os.BatteryManager
import android.os.Process
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.lisha.data.local.LishaDatabase
import com.example.lisha.data.local.LishaPreferences
import com.example.lisha.data.local.MemoryEntity
import com.example.lisha.data.local.MemoryRepository
import com.example.lisha.data.local.TaskHistoryEntity
import com.example.lisha.engine.AppAutomationManager
import com.example.lisha.engine.DualEngineManager
import com.example.lisha.engine.PrivacyLockManager
import com.example.lisha.engine.TtsManager
import com.example.lisha.engine.VoiceMatchEngine
import com.example.lisha.model.ActionType
import com.example.lisha.model.IntentType
import com.example.lisha.model.StepStatus
import com.example.lisha.model.TaskQueue
import com.example.lisha.model.TaskStep
import com.example.lisha.service.LishaAccessibilityService
import com.example.lisha.service.LishaNotificationListenerService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class LishaScreen {
    HOME,
    TASK_QUEUE,
    MEMORY_VAULT,
    DUAL_ENGINE,
    VOICE_MATCH,
    PRIVACY_LOCK,
    SYSTEM_CONTROL
}

class LishaViewModel(application: Application) : AndroidViewModel(application) {

    val repository: MemoryRepository
    val preferences: LishaPreferences

    init {
        val db = LishaDatabase.getDatabase(application)
        repository = MemoryRepository(db.memoryDao())
        preferences = LishaPreferences(application)
    }

    val memories: StateFlow<List<MemoryEntity>> = repository.allMemories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val taskHistory: StateFlow<List<TaskHistoryEntity>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentScreen = MutableStateFlow(LishaScreen.HOME)
    val currentScreen: StateFlow<LishaScreen> = _currentScreen.asStateFlow()

    private val _statusText = MutableStateFlow("Lisha is on standby • Say 'Hello Lisha'")
    val statusText: StateFlow<String> = _statusText.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _activeTaskQueue = MutableStateFlow<TaskQueue?>(null)
    val activeTaskQueue: StateFlow<TaskQueue?> = _activeTaskQueue.asStateFlow()

    private val _screenVisionSummary = MutableStateFlow<String?>(null)
    val screenVisionSummary: StateFlow<String?> = _screenVisionSummary.asStateFlow()

    private val _systemBatteryLevel = MutableStateFlow(88)
    val systemBatteryLevel: StateFlow<Int> = _systemBatteryLevel.asStateFlow()

    private val _ramUsageMb = MutableStateFlow(Pair(340L, 8192L))
    val ramUsageMb: StateFlow<Pair<Long, Long>> = _ramUsageMb.asStateFlow()

    init {
        updateDeviceTelemetry()
    }

    fun navigateTo(screen: LishaScreen) {
        _currentScreen.value = screen
    }

    private fun updateDeviceTelemetry() {
        val context = getApplication<Application>()
        try {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            val level = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 88
            _systemBatteryLevel.value = if (level in 1..100) level else 88
        } catch (e: Exception) {
            _systemBatteryLevel.value = 88
        }

        val runtime = Runtime.getRuntime()
        val usedMem = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
        val maxMem = runtime.maxMemory() / (1024 * 1024)
        _ramUsageMb.value = Pair(usedMem.coerceAtLeast(320L), maxMem.coerceAtLeast(4096L))
    }

    fun toggleVoiceListening() {
        _isListening.value = !_isListening.value
        if (_isListening.value) {
            _statusText.value = "Listening to your voice command…"
            TtsManager.speak(getApplication(), "Sun rahi hoon, boliye?")
        } else {
            _statusText.value = "Lisha is on standby"
        }
    }

    fun executeUserCommand(promptText: String) {
        if (promptText.isBlank()) return
        val context = getApplication<Application>()

        viewModelScope.launch {
            _isListening.value = false
            _statusText.value = "Verifying speaker voice match…"

            // 1. Speaker Verification
            val isAuthorized = VoiceMatchEngine.verifyVoiceSample(context, promptText)
            if (!isAuthorized && preferences.voiceMatchStrict) {
                _statusText.value = "Access Denied: Voice print mismatch"
                TtsManager.speak(context, "Voice match failed. Anjaan aawaz ko anumaati nahi hai.")
                return@launch
            }

            // 2. Privacy Lock Check
            if (PrivacyLockManager.isProtectedAction(context, promptText)) {
                _statusText.value = "Protected Action: Privacy PIN Required"
                PrivacyLockManager.requestAuthentication("Accessing secured app or private vault: '$promptText'") {
                    runCommandPipeline(promptText)
                }
                return@launch
            }

            runCommandPipeline(promptText)
        }
    }

    private fun runCommandPipeline(promptText: String) {
        val context = getApplication<Application>()
        viewModelScope.launch {
            _statusText.value = "Dual-Engine: Reasoning & Intent Routing…"
            val startTime = System.currentTimeMillis()

            val parsed = DualEngineManager.processCommand(context, promptText)

            when (parsed.intentType) {
                IntentType.SAVE_MEMORY -> {
                    val key = parsed.memoryKey ?: "note"
                    val content = parsed.memoryValue ?: promptText
                    repository.saveMemory(key, content, category = "FACT")
                    _statusText.value = "Memory saved to vault"
                    val response = parsed.directSpokenResponse ?: "Yaad rakh liya: $content"
                    TtsManager.speak(context, response)
                    repository.recordTaskExecution(promptText, "Saved to Memory Vault: $key", "Fast Lite", "SUCCESS", System.currentTimeMillis() - startTime)
                }

                IntentType.RECALL_MEMORY -> {
                    val key = parsed.memoryKey ?: ""
                    val found = repository.findMemory(key)
                    if (found != null) {
                        _statusText.value = "Memory recalled: ${found.content}"
                        val speech = "Aapne yaad rakhwaya tha: ${found.content}"
                        TtsManager.speak(context, speech)
                        repository.recordTaskExecution(promptText, "Recalled memory ($key)", "Fast Lite", "SUCCESS", System.currentTimeMillis() - startTime)
                    } else {
                        val all = memories.value
                        val partial = all.firstOrNull { it.content.contains(key, ignoreCase = true) }
                        if (partial != null) {
                            _statusText.value = "Found: ${partial.content}"
                            TtsManager.speak(context, "Mujhe mila: ${partial.content}")
                        } else {
                            _statusText.value = "No matching memory found"
                            TtsManager.speak(context, "Maaf kijiye, mujhe is baare me koi jankari nahi mili.")
                        }
                    }
                }

                IntentType.SCREEN_VISION -> {
                    analyzeCurrentScreen()
                }

                IntentType.MULTI_STEP, IntentType.APP_CONTROL, IntentType.SYSTEM_TOGGLE, IntentType.CALL_OR_MESSAGE -> {
                    if (parsed.steps.isNotEmpty()) {
                        executeTaskQueue(parsed.steps, promptText, startTime)
                    } else {
                        parsed.directSpokenResponse?.let {
                            TtsManager.speak(context, it)
                        }
                    }
                }

                IntentType.GENERAL_QA, IntentType.UNKNOWN -> {
                    val response = parsed.directSpokenResponse ?: "Command executed successfully."
                    _statusText.value = response
                    TtsManager.speak(context, response)
                    repository.recordTaskExecution(promptText, response, "Reasoning Worker", "SUCCESS", System.currentTimeMillis() - startTime)
                }
            }
        }
    }

    private fun executeTaskQueue(steps: List<TaskStep>, prompt: String, startTime: Long) {
        val context = getApplication<Application>()
        val queueId = UUID.randomUUID().toString()
        val queue = TaskQueue(
            queueId = queueId,
            originalPrompt = prompt,
            steps = steps,
            currentStepIndex = 0,
            isRunning = true
        )
        _activeTaskQueue.value = queue
        _currentScreen.value = LishaScreen.TASK_QUEUE

        viewModelScope.launch {
            val updatedSteps = steps.toMutableList()
            for (i in updatedSteps.indices) {
                val step = updatedSteps[i]
                _statusText.value = "Executing Step ${i + 1}/${steps.size}: ${step.title}"
                updatedSteps[i] = step.copy(status = StepStatus.RUNNING)
                _activeTaskQueue.value = _activeTaskQueue.value?.copy(
                    steps = updatedSteps.toList(),
                    currentStepIndex = i
                )

                delay(600) // Visual progress feedback

                // Perform action
                val success = executeIndividualStep(step)
                updatedSteps[i] = updatedSteps[i].copy(
                    status = if (success) StepStatus.COMPLETED else StepStatus.FAILED,
                    executionLog = if (success) "Completed smoothly" else "Fallback applied"
                )
                _activeTaskQueue.value = _activeTaskQueue.value?.copy(
                    steps = updatedSteps.toList()
                )
                delay(300)
            }

            _activeTaskQueue.value = _activeTaskQueue.value?.copy(
                isRunning = false,
                completedSuccessfully = true
            )
            _statusText.value = "All ${steps.size} steps completed"
            TtsManager.speak(context, "Aapka poora task pipeline poora ho gaya hai.")
            repository.recordTaskExecution(
                prompt = prompt,
                summary = "${steps.size} steps: " + steps.joinToString { it.title },
                engine = "Dual-Engine Pipeline",
                status = "SUCCESS",
                durationMs = System.currentTimeMillis() - startTime
            )
        }
    }

    private fun executeIndividualStep(step: TaskStep): Boolean {
        val context = getApplication<Application>()
        return when (step.actionType) {
            ActionType.OPEN_APP -> {
                AppAutomationManager.launchAppByName(context, step.target)
            }
            ActionType.TOGGLE_SETTING -> {
                when (step.target) {
                    "torch_on" -> AppAutomationManager.toggleFlashlight(context, true)
                    "torch_off" -> AppAutomationManager.toggleFlashlight(context, false)
                    "wifi_settings" -> AppAutomationManager.openWifiSettings(context)
                    "bluetooth_settings" -> AppAutomationManager.openBluetoothSettings(context)
                    "volume_up" -> AppAutomationManager.adjustVolume(context, android.media.AudioManager.ADJUST_RAISE)
                    "volume_down" -> AppAutomationManager.adjustVolume(context, android.media.AudioManager.ADJUST_LOWER)
                    "alarm_clock" -> AppAutomationManager.setAlarm(context, 7, 0, "Lisha Automation")
                    else -> true
                }
            }
            ActionType.SCREEN_LOCK -> {
                AppAutomationManager.lockScreenSafely()
            }
            ActionType.MAKE_CALL -> {
                AppAutomationManager.launchDialer(context, step.target)
            }
            ActionType.CLICK_NODE -> {
                LishaAccessibilityService.findAndClick(step.target)
            }
            ActionType.TYPE_TEXT -> {
                LishaAccessibilityService.inputText(step.target)
            }
            ActionType.SEND_MESSAGE -> {
                AppAutomationManager.launchAppByName(context, "whatsapp")
            }
            else -> true
        }
    }

    fun analyzeCurrentScreen() {
        val context = getApplication<Application>()
        viewModelScope.launch {
            _statusText.value = "Screen Vision: Reading UI node hierarchy…"
            val elements = LishaAccessibilityService.extractVisibleScreenElements()
            val summary = if (elements.size <= 2) {
                "Screen shows: ${LishaAccessibilityService.currentScreenTitle.value} (${LishaAccessibilityService.currentForegroundPackage.value})"
            } else {
                "On Screen: " + elements.take(8).joinToString(", ")
            }
            _screenVisionSummary.value = summary
            _statusText.value = "Screen analyzed"
            TtsManager.speak(context, summary)
        }
    }

    fun simulateIncomingNotification(sender: String, message: String, isCall: Boolean) {
        val appName = if (isCall) "Phone" else "WhatsApp"
        val announcement = com.example.lisha.model.NotificationAnnouncement(
            appName = appName,
            sender = sender,
            message = message,
            isCall = isCall
        )
        LishaNotificationListenerService.postSimulatedAnnouncement(announcement)
        val speech = if (isCall) {
            "Aapko $sender ka call aa raha hai"
        } else {
            "WhatsApp par $sender se naya message: $message"
        }
        TtsManager.speak(getApplication(), speech)
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch {
            repository.deleteMemory(id)
        }
    }

    fun addManualMemory(key: String, content: String, category: String) {
        viewModelScope.launch {
            repository.saveMemory(key, content, category)
        }
    }
}
