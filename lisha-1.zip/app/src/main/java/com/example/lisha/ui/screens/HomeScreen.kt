package com.example.lisha.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.lisha.engine.AppAutomationManager
import com.example.lisha.engine.DualEngineManager
import com.example.lisha.engine.TtsManager
import com.example.lisha.service.LishaAccessibilityService
import com.example.lisha.ui.components.HolographicOrb
import com.example.lisha.viewmodel.LishaScreen
import com.example.lisha.viewmodel.LishaViewModel
import com.example.ui.theme.LishaAlertRed
import com.example.ui.theme.LishaBorder
import com.example.ui.theme.LishaElectricViolet
import com.example.ui.theme.LishaMintSuccess
import com.example.ui.theme.LishaNeonCyan
import com.example.ui.theme.LishaObsidian
import com.example.ui.theme.LishaPurpleGlow
import com.example.ui.theme.LishaSurface
import com.example.ui.theme.LishaSurfaceHigh
import com.example.ui.theme.LishaSurfaceVariant
import com.example.ui.theme.LishaTextPrimary
import com.example.ui.theme.LishaTextSecondary

@Composable
fun HomeScreen(
    viewModel: LishaViewModel,
    onNavigate: (LishaScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val statusText by viewModel.statusText.collectAsState()
    val isListening by viewModel.isListening.collectAsState()
    val isSpeaking by TtsManager.isSpeaking.collectAsState()
    val waveforms by TtsManager.waveformAmplitudes.collectAsState()
    val screenVisionSummary by viewModel.screenVisionSummary.collectAsState()
    val dualStatus by DualEngineManager.engineStatus.collectAsState()
    val isAccessibilityActive by LishaAccessibilityService.isAccessibilityActive.collectAsState()

    var inputCommand by remember { mutableStateOf("") }

    val quickCommands = listOf(
        "WiFi chalu karo, Instagram kholo, aur message bhejo",
        "Torch chalu karo",
        "Ye yaad rakho ki mera car parking B2 slot 45 me hai",
        "Mera car parking kaha hai?",
        "Mom ko call karo",
        "Volume badhao",
        "Screen band karo"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(LishaObsidian)
            .padding(horizontal = 16.dp)
            .testTag("home_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Futuristic Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(18.dp)),
                colors = CardDefaults.cardColors(containerColor = LishaSurface)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.lisha_hero_banner),
                        contentDescription = "Lisha Cybernetic Banner",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        LishaObsidian.copy(alpha = 0.85f),
                                        Color.Transparent
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "LISHA AUTONOMOUS AGENT",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = LishaNeonCyan,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.5.sp
                            )
                        )
                        Text(
                            text = "Hands-Free Phone Control",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Black
                            )
                        )
                        Text(
                            text = "Dual API Parallel Engine • Biometric Voice Match",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = LishaTextSecondary,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }
        }

        // Holographic Voice Orb
        item {
            HolographicOrb(
                isListening = isListening,
                isSpeaking = isSpeaking,
                statusText = statusText,
                waveforms = waveforms,
                onClick = {
                    viewModel.toggleVoiceListening()
                },
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Voice / Text Command Input Bar
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = LishaSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, LishaBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.toggleVoiceListening() },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (isListening) LishaMintSuccess else LishaSurfaceHigh)
                            .testTag("mic_toggle_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Voice Input",
                            tint = if (isListening) Color.Black else LishaNeonCyan,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    OutlinedTextField(
                        value = inputCommand,
                        onValueChange = { inputCommand = it },
                        placeholder = { Text("Command Lisha in English or Hindi…", fontSize = 13.sp, color = LishaTextSecondary) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("command_input_field")
                    )

                    IconButton(
                        onClick = {
                            if (inputCommand.isNotBlank()) {
                                viewModel.executeUserCommand(inputCommand)
                                inputCommand = ""
                            }
                        },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(LishaNeonCyan)
                            .testTag("send_command_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Execute Command",
                            tint = Color.Black,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // Screen Vision / Reading HUD Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("screen_vision_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = LishaSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, LishaBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Visibility,
                                contentDescription = "Screen Vision",
                                tint = LishaNeonCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "SCREEN VISION / READING",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = LishaTextPrimary,
                                    letterSpacing = 1.sp
                                )
                            )
                        }

                        Button(
                            onClick = { viewModel.analyzeCurrentScreen() },
                            colors = ButtonDefaults.buttonColors(containerColor = LishaSurfaceHigh),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("analyze_screen_button")
                        ) {
                            Text("Scan Screen", fontSize = 12.sp, color = LishaNeonCyan)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = screenVisionSummary
                            ?: "Lisha reads live UI hierarchies and screen layouts. Tap 'Scan Screen' or say 'Screen par kya hai'.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = if (screenVisionSummary != null) Color.White else LishaTextSecondary,
                            lineHeight = 18.sp
                        )
                    )
                }
            }
        }

        // Quick Command Chains
        item {
            Text(
                text = "VOICE QUICK CHAINS",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = LishaTextSecondary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(quickCommands) { cmd ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = LishaSurfaceHigh,
                        border = androidx.compose.foundation.BorderStroke(1.dp, LishaBorder),
                        modifier = Modifier
                            .clickable {
                                viewModel.executeUserCommand(cmd)
                            }
                            .testTag("quick_chain_${cmd.take(10)}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = null,
                                tint = LishaPurpleGlow,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = cmd,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                    }
                }
            }
        }

        // Smart Announcer Test Simulation Hub
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = LishaSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, LishaBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "SMART CALLER & MESSAGE ANNOUNCER",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = LishaTextPrimary,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Announces incoming calls & WhatsApp messages out loud in Hindi & English.",
                        style = MaterialTheme.typography.bodySmall.copy(color = LishaTextSecondary)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.simulateIncomingNotification("Rahul Sharma", "Urgent Call", isCall = true)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = LishaMintSuccess.copy(alpha = 0.2f)),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("test_caller_button")
                        ) {
                            Icon(Icons.Default.Phone, contentDescription = null, tint = LishaMintSuccess, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Test Call Alert", fontSize = 11.sp, color = LishaMintSuccess, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                viewModel.simulateIncomingNotification("Mom", "Ghar kab aaoge beta?", isCall = false)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = LishaNeonCyan.copy(alpha = 0.2f)),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("test_message_button")
                        ) {
                            Icon(Icons.Default.Chat, contentDescription = null, tint = LishaNeonCyan, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Test Message Alert", fontSize = 11.sp, color = LishaNeonCyan, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Quick App Launcher Bar
        item {
            Text(
                text = "AUTONOMOUS DOCKED APPS",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = LishaTextSecondary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val launcherApps = listOf(
                    Triple("WhatsApp", Icons.Default.Chat, "whatsapp"),
                    Triple("Camera", Icons.Default.CameraAlt, "camera"),
                    Triple("Phone", Icons.Default.Phone, "dialer"),
                    Triple("Torch", Icons.Default.FlashOn, "torch"),
                    Triple("Volume", Icons.Default.VolumeUp, "volume"),
                    Triple("Settings", Icons.Default.Settings, "settings")
                )

                launcherApps.forEach { (name, icon, target) ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable {
                                if (target == "torch") {
                                    AppAutomationManager.toggleFlashlight(context)
                                } else if (target == "volume") {
                                    AppAutomationManager.adjustVolume(context, android.media.AudioManager.ADJUST_RAISE)
                                } else {
                                    AppAutomationManager.launchAppByName(context, target)
                                }
                            }
                            .testTag("dock_app_$target")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(LishaSurfaceHigh)
                                .border(1.dp, LishaBorder, RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = name,
                                tint = LishaNeonCyan,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = name,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = LishaTextSecondary,
                                fontSize = 10.sp
                            )
                        )
                    }
                }
            }
        }

        // Engine Status Telemetry Bar
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = LishaSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, LishaBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Engine Route:",
                            style = MaterialTheme.typography.labelSmall.copy(color = LishaTextSecondary)
                        )
                        Text(
                            text = dualStatus.lastRouteReason,
                            style = MaterialTheme.typography.bodySmall.copy(color = LishaTextPrimary, fontSize = 12.sp)
                        )
                    }
                    Button(
                        onClick = { onNavigate(LishaScreen.DUAL_ENGINE) },
                        colors = ButtonDefaults.buttonColors(containerColor = LishaSurfaceHigh),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("manage_keys_button")
                    ) {
                        Text("2-Keys HUD", fontSize = 11.sp, color = LishaNeonCyan)
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
