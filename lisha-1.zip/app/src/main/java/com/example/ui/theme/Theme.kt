package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LishaDarkColorScheme = darkColorScheme(
    primary = LishaNeonCyan,
    onPrimary = Color.Black,
    primaryContainer = LishaSurfaceHigh,
    onPrimaryContainer = LishaNeonCyan,
    secondary = LishaElectricViolet,
    onSecondary = Color.White,
    secondaryContainer = LishaPurpleGlow.copy(alpha = 0.2f),
    onSecondaryContainer = LishaPurpleGlow,
    tertiary = LishaMintSuccess,
    onTertiary = Color.Black,
    background = LishaObsidian,
    onBackground = LishaTextPrimary,
    surface = LishaSurface,
    onSurface = LishaTextPrimary,
    surfaceVariant = LishaSurfaceVariant,
    onSurfaceVariant = LishaTextSecondary,
    outline = LishaBorder,
    error = LishaAlertRed,
    onError = Color.White
)

@Composable
fun LishaTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LishaDarkColorScheme,
        typography = Typography,
        content = content
    )
}
