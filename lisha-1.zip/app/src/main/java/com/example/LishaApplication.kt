package com.example

import android.app.Application
import com.example.lisha.data.local.LishaDatabase
import com.example.lisha.data.local.MemoryEntity
import com.example.lisha.engine.TtsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class LishaApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        TtsManager.init(this)
        
        // Seed default helpful memories if database is empty
        val db = LishaDatabase.getDatabase(this)
        CoroutineScope(Dispatchers.IO).launch {
            val existing = db.memoryDao().getAllMemories().first()
            if (existing.isEmpty()) {
                db.memoryDao().insertMemory(
                    MemoryEntity(
                        keyPhrase = "car_parking",
                        content = "Car parked in B2 Basement - Slot 45 near Pillar C",
                        category = "FACT",
                        isPinned = true
                    )
                )
                db.memoryDao().insertMemory(
                    MemoryEntity(
                        keyPhrase = "mom_birthday",
                        content = "Mom's birthday is on November 15th",
                        category = "ROUTINE",
                        isPinned = true
                    )
                )
                db.memoryDao().insertMemory(
                    MemoryEntity(
                        keyPhrase = "wifi_password",
                        content = "Home WiFi: CyberLisha_Ultra (Pass: Quantum#2026)",
                        category = "SECRET",
                        isPinned = false
                    )
                )
            }
        }
    }
}
